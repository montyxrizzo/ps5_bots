
from selenium import webdriver
# from webdriver_manager.chrome import ChromeDriverManager
from time import sleep
import  boto3
import sys
import inspect
print(sys.getrecursionlimit())
from twilio.rest import Client

x=3000
sys.setrecursionlimit(x)
# Your Account SID from twilio.com/console
account_sid = "AC9169780a1a1ef0dab42d0c4d9e6c1735"
# Your Auth Token from twilio.com/console
auth_token  = "2a83b0f698211d577bd5be585b6eb422"
client = Client(account_sid, auth_token)
found = False

class PS5Bot():
    def __init__(self):
        # self.driver = webdriver.Chrome()
        self.driver  = webdriver.Chrome(executable_path='/Users/montyrodgers/chromedriver')


    def login(self):
        self.driver.get('https://www.amazon.com')
        message = client.messages \
                .create(
                     body="PS5 Fishing Started...",
                     from_='+14843194946',
                     to='+12169066920'
                 )

        print(message.sid)

        sleep(130)

    def checkAndBuyPS5(self):
        self.driver.get('https://www.amazon.com/PlayStation-5-Digital/dp/B08FC6MR62/ref=sr_1_1?crid=1RT7I3C8KRVYR&dchild=1&keywords=ps5+digital+edition&qid=1616945596&sprefix=ps5+digitl%2Caps%2C163&sr=8-1')
        sleep(5)   
        try:
            buyNow = self.driver.find_element_by_xpath('//*[@id="submit.add-to-cart"]') 
            buyNow.click()
            message = client.messages \
                .create(
                     body="PS5 ADDED to cart!!!",
                     from_='+14843194946',
                     to='+12169066920'
                 )
            sleep(2)
            found = True
            # buyNow2 = self.driver.find_element_by_xpath('//*[@id="hlb-ptc-btn"]')
            # buyNow2.click()
            # sleep(2)
            # buyNow3 = self.driver.find_element_by_xpath('/html/body/div[5]/div/div[2]/form/div/div/div/div[2]/div/div[1]/div/div[1]/div/span/span/input')  
            # buyNow3.click()
            # sleep(1)
            message = client.messages \
                .create(
                     body="PS5 Added to amazon cart!!!! Go check out NOW!!!",
                     from_='+14843194946',
                     to='+12169066920'
                 )

            print(message.sid)

            self.driver.close()
            return True
        except Exception as e:
            print(e)
            sleep(1)
            return False
            # self.checkAndBuyPS5()

bot = PS5Bot()
bot.login()
while (found == False):
    bot.checkAndBuyPS5()
    sleep(60)
print("Stopping.")
sleep(1000000000000000030)



