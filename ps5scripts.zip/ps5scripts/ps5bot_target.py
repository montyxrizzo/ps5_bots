from selenium import webdriver
# from webdriver_manager.chrome import ChromeDriverManager
from time import sleep
import  boto3
import sys
import inspect
print(sys.getrecursionlimit())
from twilio.rest import Client

x=3000
sys.setrecursionlimit(x)
# Your Account SID from twilio.com/console
account_sid = "AC9169780a1a1ef0dab42d0c4d9e6c1735"
# Your Auth Token from twilio.com/console
auth_token  = "2a83b0f698211d577bd5be585b6eb422"
client = Client(account_sid, auth_token)
found = False

class PS5Bot():
    def __init__(self):
        self.driver  = webdriver.Chrome(executable_path='/Users/montyrodgers/chromedriver')


    def login(self):
        self.driver.get('https://www.target.com')
        # message = client.messages \
        #         .create(
        #              body="PS5 Fishing Started at best buy...",
        #              from_='+14843194946',
        #              to='+12169066920'
        #          )

        # print(message.sid)

        sleep(60)

    def checkAndBuyPS5(self):
        # self.driver.get('https://www.walmart.com/ip/Sony-PlayStation-5-Digital-Edition/493824815')
        self.driver.get('https://www.target.com/p/playstation-5-digital-edition-console/-/A-81114596')
        # self.driver.get('https://www.bestbuy.com/site/hp-deskjet-3755-wireless-all-in-one-instant-ink-ready-inkjet-printer-stone/5234375.p?skuId=5234375')

        sleep(1)   
        try:
            sleep(1.5) 
            buyNow = self.driver.find_element_by_xpath('//*[@data-test="shipItButton"]') 
            
            if (buyNow.is_enabled() == True):
                buyNow.click()
                message = client.messages \
                .create(
                     body="PS5 ADDED to TARGET cart!!!",
                     from_='+14843194946',
                     to='+12169066920'
                 )
                sleep(2)
                found = True
                print(message.sid)
                sleep(2)
                # self.driver.close()
                return True

            else:
                found = False
                sleep(2)

                # self.driver.close()
                return False
        except Exception as e:
            print(e)
            sleep(1)
            # self.driver.close()
            return False

            # self.checkAndBuyPS5()

bot = PS5Bot()
bot.login()
while (found == False):
        bot.checkAndBuyPS5()
        sleep(120)

self.driver.close()
print("Stopping.")

sleep(100000000000)




